<!-- ======= Footer ======= -->
<footer id="footer">
    <div class="container">
        <div class="copyright">
           Develop <strong><span>By</span></strong> Mahasiswa
        </div>
        <div class="credits">
            @STT-NF 2020
        </div>
    </div>
</footer><!-- End Footer -->