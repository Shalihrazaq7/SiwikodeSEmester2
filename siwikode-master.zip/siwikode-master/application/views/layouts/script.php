 <!-- Vendor JS Files -->
 <script src="<?= base_url("public/assets/vendor/jquery/jquery.min.js") ?>"></script>
 <script src="<?= base_url("public/assets/vendor/bootstrap/js/bootstrap.bundle.min.js") ?>"></script>
 <script src="<?= base_url("public/assets/vendor/jquery.easing/jquery.easing.min.js") ?>"></script>
 <script src="<?= base_url("public/assets/vendor/forminput/validate.js") ?>"></script>
 <script src="<?= base_url("public/assets/vendor/isotope-layout/isotope.pkgd.min.js") ?>"></script>
 <script src="<?= base_url("public/assets/vendor/venobox/venobox.min.js") ?>"></script>
 <script src="<?= base_url("public/assets/vendor/owl.carousel/owl.carousel.min.js") ?>"></script>
 <script src="<?= base_url("public/assets/vendor/aos/aos.js") ?>"></script>

 <!-- Template Main JS File -->
 <script src="<?= base_url("public/assets/js/main.js") ?>"></script>